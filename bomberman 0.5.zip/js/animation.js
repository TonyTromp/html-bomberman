function animation(id,parent) {
     var _frames = new Array();
     var intervalID;
     var IsPlaying = false;
     
     this.id           = id;
     this.frames       = _frames;
     this.currentFrame = 0;
     this.addFrame     = addFrame;
     this.Parent = parent;
     this.IsPlaying = IsPlaying;

     this.Play  = Play;
     this._play = _play;
     this.Stop  = Stop;
     
     this.setImageClip = setImageClip;
     
     function addFrame(offsetx,offsety)
     {
        _frames[ _frames.length ] = new frame( offsetx , offsety , this);
     }

     function frame(x, y , parent) {
       this.x = x;
       this.y = y;
       this.parent = parent;
     }     

     function setImageClip(elementID, x,y)
     {
        var gameObject = document.getElementById(elementID);
        gameObject.style.backgroundPosition  = '-'+ x +'px '+ y +'px';
        gameObject.style.backgroundPosition  = '-'+ x +'px '+ y +'px';
     }

     function Play(elementID) {
        var strFuncCallBack = this.Parent.id + ".GetAnimationByID('"+ this.id +"')._play('"+ elementID +"')";
        this.Parent.StopAllAnimations(elementID);
        intervalID = window.setInterval( strFuncCallBack, 100);
        this.IsPlaying = true;
     }
     
     function _play(elementID)
     {
       if (this.currentFrame<(this.frames.length-1))
       {
          this.currentFrame++;
       } else {
         this.currentFrame = 1; // 0 = note the stopping image, when not animating
       }
       var newX = this.frames[this.currentFrame].x;
       var newY = this.frames[this.currentFrame].y;

       setImageClip(elementID,newX,newY);
     }
     
     function Stop()
     {
        if (intervalID) {
           window.clearInterval(intervalID);
           this.IsPlaying = false;
        }
        
     } 

}

/*
** creates a new inline DIV element representing a game_element
**
** within the DIV you specify the following objects
** id                - (string) objectid for the element
** url_spriteobject  - (string) url to sprite resource
**
** x       - (int) x position to place the element
** y       - (int) y position to place the element
** width   - (int) width of the element
** heigth  - (int) heigth of the element
** cell_x  - (int) sprite cell x position
** cell_y  - (int) sprite cell y position
** visible - (boolean) determines if to show the image.
*/

function gameobject(id , url_spriteobject , x , y , width, height , cell_x , cell_y , visible) {
     var IsMoving      = false;
     var width;
     var height;
     var _animations   = new Array();
     this.addAnimation = addAnimation;

     this.id = id;
     this.GetAnimationByID  = GetAnimationByID;
     this.PlayAnimation     = PlayAnimation;
     this.StopAllAnimations = StopAllAnimations;
     this.SmoothMove        = SmoothMove;
     this._SmoothMove       = _SmoothMove;
     
     this.IsMoving   = IsMoving;     
     this.beforeMove = window.event;
     this.afterMove  = window.event;
     
     this.x = x;
     this.y = y;
     this.width  = width;
     this.height = height;
     
     var new_element = document.createElement('DIV');
     new_element.setAttribute('id' , id + '_element');
     document.body.appendChild(new_element);
     
     var game_element = document.getElementById(new_element.id);
      
     game_element.style.position = 'absolute';
     game_element.style.width    = width  + 'px';
     game_element.style.height   = height + 'px';
     game_element.style.left     = x + 'px';
     game_element.style.top      = y + 'px';
     
     // Add eventListener for W3C^mozilla
     if (game_element.addEventListener)
        game_element.addEventListener('click',custom_event,false);
     // Add eventListener for Explorer
     if (game_element.attachEvent)
        game_element.attachEvent( 'onclick' , custom_event );
        
     function custom_event(e) {
        alert('Hello from event' + e);
     }
     
     //game_element.fireEvent("onclick");
     
     

     if (url_spriteobject) game_element.style.backgroundImage     = 'url('+ url_spriteobject +')';      
     if (cell_x | cell_y)  game_element.style.backgroundPosition  = '-'+ cell_x +'px '+ cell_y +'px';
     if (visible==false) { 
       game_element.style.visibility = 'Hidden' 
     } else {
       game_element.style.visibility = 'Visible' 
     }
     

     function addAnimation(animation, id)
     {
        _animations[ _animations.length ] = animation;
        _animations[ _animations.length - 1 ].id = id;
        _animations[ _animations.length - 1 ].Parent = this;
     }
     
     function GetAnimationByID(animationID)
     {
        for (i=0 ; i<=(_animations.length -1); i++)
        {
            if (_animations[i].id == animationID)
            {
            return _animations[i];
            }
        }
        
        alert('Error:GetAnimationByID, animationID ' + animationID + ' not found');

        return null;
     }

     function PlayAnimation(animationID) {
        this.GetAnimationByID(animationID).Play( this.id + '_element' );
        this.IsPlaying = true;
     }
     
     function StopAllAnimations()
     {
        for (i=0; i<_animations.length ; i++)
        {
            if (_animations[i].IsPlaying)
            {
               _animations[i].Stop();
               _animations[i].currentFrame = 0;
               var newX = _animations[i].frames[0].x;
               var newY = _animations[i].frames[0].y;
               _animations[i].setImageClip(this.id + '_element',newX,newY);
            }
        }
     }
     
     function SmoothMove(destX, destY, time) {     
        obj = document.getElementById(this.id + '_element');
        obj.startX = obj.offsetLeft;
        obj.startY = obj.offsetTop;
        obj.destX = destX;
        obj.destY = destY;
        obj.time = time;
        obj.tick = 0;
        this.IsMoving = true;
        obj.timer = setInterval(this.id + "._SmoothMove('"+ id +"')", 40);
     }

     function _SmoothMove(id) {
       obj = document.getElementById(id + '_element');
       obj.tick += 40;

       if (obj.tick >= obj.time) {
         obj.tick = obj.time;
         clearInterval(obj.timer);
         obj.timer = null;
         this.IsMoving = false;
         afterMove();
       }
 
       var x = obj.destX - obj.startX;
       var y = obj.destY - obj.startY;
       var t = obj.tick / obj.time * Math.PI;
       this.x = obj.startX - 0.5 * x * Math.cos(t) + 0.5 * x;
       this.y = obj.startY - 0.5 * y * Math.cos(t) + 0.5 * y;
       obj.style.left = this.x +'px';
       obj.style.top  = this.y +'px';
     }
   
      

}